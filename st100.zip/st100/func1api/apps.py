from django.apps import AppConfig


class Func1ApiConfig(AppConfig):
    name = 'func1api'
